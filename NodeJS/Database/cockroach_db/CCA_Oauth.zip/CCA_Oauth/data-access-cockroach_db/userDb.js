function userDb({}) {
  return async function userDbs() {
    return Object.freeze({
        getAllUserQuery
    });


    async function getAllUserQuery(){
        let somequery 
    }
  };
}

module.exports = userDb
