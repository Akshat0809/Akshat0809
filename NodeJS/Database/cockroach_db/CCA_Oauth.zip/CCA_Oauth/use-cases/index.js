// console.log("use case index.js")
const users = require('./users');
const folders = require('./folders');
module.exports = Object.freeze({
    users,
    folders,
})